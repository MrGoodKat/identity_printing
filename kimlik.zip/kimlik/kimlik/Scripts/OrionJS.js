﻿$(document).ready(function () {

    

    $("#front-side-button").click(function (e) {
        $('head').append('<link href="/Content/print_front.css" media="print" id="printCSS" />');
        html2canvas($("#front-side"), {
            onrendered: function (canvas) {

                $("#popup-body").empty();
                $("#print-2").hide();
                $("#print-1").show();

                $("#popup-body").append(canvas);
                var myImage = canvas.toDataURL("image/png");
                ////Canvas2Image.saveAsPNG(canvas);
                $("#popup-body").find("canvas").attr('id', 'canvas-1');

                $("#print-1").click(function (canvas) {
                    $("#printCSS").remove();
                    $('head').append('<link href="/Content/print_front.css" media="print" id="printCSS" />');

                    canvas = myImage;
                    var w = window.open('about:blank', 'image from canvas');
                    w.document.write("<img src='" + canvas + "' alt='from canvas' />");
                    w.print();
                    w.close();

                });
                

            }
        });
        e.isPropagationStopped();
    });

    $("#back-side-button").click(function (e) {

        html2canvas($("#second-side"), {
            onrendered: function (canvas) {

                thCanvas = canvas;

                $("#popup-body").empty();
                $("#print-1").hide();
                $("#print-2").show();
                $("#popup-body").append(canvas);
                var myImage = canvas.toDataURL("image/png");
                ////Canvas2Image.saveAsPNG(canvas);
                $("#popup-body").find("canvas").attr('id', 'canvas-2');

                $("#print-2").click(function (canvas) {
                    $("#printCSS").remove();
                    $('head').append('<link href="/Content/print_back.css" media="print" id="printCSS" />');
                    //Canvas kısmını burda elde ettim


                    canvas = myImage;
                    //Canvas kısmını burda elde ettim


                    var w = window.open('about:blank', 'image from canvas');
                    w.document.write("<img src='" + canvas + "' alt='from canvas' width='700' height='500'/>");

                    w.print();
                    w.close();

                });

            }
        });

        e.isPropagationStopped();

    });


    if (window.location.href.indexOf("KimlikTasarla") > -1) {


        CardFrontColor();

        CardFrontPanoColor();

        CardHeaderPanoColorBack();

        CardBackColor();

        CardFrontPanoColorBack();

        CardFontMiddleHeaderColor();

        CardFontLabelColor();

        CardFrontPanoColorBackTitle();

        CardFontColor();

        DisplayCardSide();

        $("#ImageLeft").change(function () {
            readURLLeftLogo(this);
        });
        $("#ImageRight").change(function () {
            readURLRightLogo(this);
        });

        $(".card-right").affix({
            offset: {
                top: $('.card-right').height()
            }
        });
    }

    if (window.location.href.indexOf("MainPage") > -1 || window.location.href.indexOf("KimlikDuzenleme") > -1) {
        $("#ImagePath").change(function () {
            readURLImagePath(this);
        });
    }

    



});

$(document).scroll(function () {
    if (window.location.href.indexOf("KimlikTasarla") > -1) {

        var scroll = $(window).scrollTop();

        if (scroll>=150) {
            
            $('.card-right').addClass('new-position-cardRight');
        }
        else {
            $('.card-right').removeClass('new-position-cardRight');
        }

    }
});

function DisplayCardSide() {
    $("#second-side").hide();
    $("#front-side").hide();


    $("#front-side-area").on("mouseenter", function () {
        $("#front-side").fadeIn();
        $("#second-side").hide();
    });

    $("#second-side-area").on("mouseenter", function () {
        $("#second-side").fadeIn();
        $("#front-side").hide();
    });

}




function CardFrontColor() {
    var bodyStyle = $('.card-container')[0].style;
    $('.card-front-bg').colorpicker({
        color: bodyStyle.backgroundColor
    }).on('changeColor', function (ev) {
        bodyStyle.backgroundColor = ev.color.toHex();
    });

}

function CardBackColor() {

    var bodyStyle = $('.card-container')[1].style;
    $('.card-front-bg').colorpicker({
        color: bodyStyle.backgroundColor
    }).on('changeColor', function (ev) {
        bodyStyle.backgroundColor = ev.color.toHex();
    });

}

function CardFrontPanoColor() {
    var bodyStyle = $('#card-front-pano')[0].style;
    $('.card-pano-bg').colorpicker({
        color: bodyStyle.backgroundColor
    }).on('changeColor', function (ev) {
        bodyStyle.backgroundColor = ev.color.toHex();
    });
}

function CardFrontPanoColorBackTitle() {
    var bodyStyle = $('.second-header')[0].style;
    $('.card-pano-bg').colorpicker({
        color: bodyStyle.backgroundColor
    }).on('changeColor', function (ev) {
        bodyStyle.backgroundColor = ev.color.toHex();
    });
}
function CardFrontPanoColorBack() {
    var bodyStyle = $('.back-side')[0].style;
    $('.card-pano-bg').colorpicker({
        color: bodyStyle.backgroundColor
    }).on('changeColor', function (ev) {
        bodyStyle.backgroundColor = ev.color.toHex();
    });
}

function CardHeaderPanoColorBack() {
    var bodyStyle = $('.card-header')[0].style;
    $('.card-pano-bg').colorpicker({
        color: bodyStyle.backgroundColor
    }).on('changeColor', function (ev) {
        bodyStyle.backgroundColor = ev.color.toHex();
    });
}

function CardFontColor() {
    //var bodyStyle = $('.back-side')[0].style;

    var bodyStyle = $('.card-font-color')[0].style;
    $('.card-font-color').colorpicker().on('changeColor.colorpicker', function (event) {
        var colorText = bodyStyle.backgroundColor = event.color.toHex();
        
        $(".data-container label").css("color", colorText);
        $(".get-right label").css("color", colorText);
    });
}

function CardFontLabelColor() {
    //var bodyStyle = $('.back-side')[0].style;

    var bodyStyle = $('.card-font-label-color')[0].style;
    $('.card-font-label-color').colorpicker().on('changeColor.colorpicker', function (event) {
        var colorText = bodyStyle.backgroundColor = event.color.toHex();
        
        $(".label-container label").css("color", colorText);
        
    });
}
function CardFontMiddleHeaderColor() {
    
    var bodyStyle = $('.card-font-middle-color')[0].style;
    $('.card-font-middle-color').colorpicker().on('changeColor.colorpicker', function (event) {
        var colorText = bodyStyle.backgroundColor = event.color.toHex();
    
        $(".cc-second h6").css("color", colorText);
    
    });
}

//card-pano-bg
function readURLLeftLogo(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#left-logo').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

function readURLRightLogo(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#right-logo').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

//ImagePath
function readURLImagePath(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.img-responsive').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}